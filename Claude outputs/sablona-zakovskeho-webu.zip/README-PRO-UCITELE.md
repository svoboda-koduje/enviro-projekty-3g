# Šablona žákovského webu – poznámky pro učitele

Tahle složka je **zdrojem šablony**, ze které si žáci budou vytvářet
vlastní repozitáře přes tlačítko „Use this template“. Než ji zpřístupníš
třídě, projdi tenhle checklist.

## 1. Logo školy – už je hotovo

Do `assets/skola-logo.png` jsem rovnou vložil skutečné logo SPŠE a VOŠ
Pardubice (bílou variantu pro tmavý pruh v hlavičce) – vzal jsem ho přímo
z tvého webu `enviro-projekty-3g`. Nemusíš nic dělat, logo bude mít
automaticky **každý** žákovský web, který ze šablony vznikne.

## 2. Založ repozitář a označ ho jako šablonu

1. Na GitHubu vytvoř nový **veřejný** repozitář, např. `enviro-sablona-3g`.
2. Nahraj do něj obsah téhle složky (`index.html`, `style.css`, `assets/`).
3. Settings → v sekci **General** zaškrtni **Template repository**.
4. Od teď se na hlavní stránce repozitáře zobrazuje zelené tlačítko
   **„Use this template“** – přesně ten odkaz půjde do návodu pro žáky
   (`navod-pro-zaky.html`, řádek s `ODKAZ_NA_SABLONU`).

## 3. Co šablona obsahuje

- `index.html` – sekce podle etap zadání: slogan/claim, vizuální
  identita (paleta + typografie), moodboard, mikroanimace (mp4 i
  YouTube varianta), bannery/sociální sítě, obalový design, plakát
  (klikatelný náhled → PDF) a PDF portfolio.
- `style.css` – nahoře v `:root` jsou proměnné pro barvy/písmo/zaoblení,
  které si žáci mohou bezpečně měnit, aniž by rozbili rozvržení.
- `assets/` – placeholder obrázky/PDF/mp4 se sufixem `-NAHRAD`, aby žák
  přesně věděl, který soubor má nahradit a v jakém rozměru/formátu.

## 4. Proč zrovna takhle (shrnutí doporučení)

- **GitHub Pages + šablonový repozitář** = zdarma, bez reklam, s vlastní
  trvalou adresou `uzivatel.github.io/nazev-repo`, a hlavně: cokoliv
  jednou dáš do šablony (logo, strukturu, branding), mají automaticky
  všichni žáci. Google Sites nebo Carrd tohle neumí – šablonu přes ně
  nejde hromadně distribuovat.
- Žáci nepotřebují znát Git ani nic instalovat – veškerá úprava jde přes
  webové rozhraní GitHubu (editace souboru přes ✏️, nahrání souboru přes
  „Add file → Upload files“). Návod s tím počítá.
- Video: šablona podporuje jak mp4 přímo v repozitáři (jednodušší, ale
  drž se pod cca 20–25 MB/soubor), tak YouTube embed (bez limitu
  velikosti, ale žák potřebuje Google účet). Necháno na volbě žáka.
- Limity GitHub Pages (aktuální dokumentace, 2026): doporučený limit
  zdrojového repozitáře 1 GB, měkký limit přenosu dat 100 GB/měsíc,
  žádný jednotlivý soubor přes 100 MB (nad to je potřeba Git LFS).
  Pro 28 samostatných repozitářů (každý žák = vlastní účet a repozitář)
  tohle není problém – limity se totiž počítají za repozitář/účet, ne
  dohromady za školu.

## 5. Propojení s rozcestníkem

Viz `doplnek-pro-rozcestnik/` – ukázka, jak do tabulky žáků na tvém
webu přidat sloupec s odkazem na jejich web a tlačítko otevírající
`navod-pro-zaky.html`.
